![CoderStory](src/assets/coderstory_git.jpg)

# What is CoderStory?

Every Coder has a story to share and CodeStory makes sure that this story is designed professionally. The portfolio that you create at CodeStory will provide you with options to enhance the story with the languages you learnt that were used to create your projects all night infact nights together and finally the certifications that prove you are a pro.

## How did we go about coding CoderStory

We are a team of 4 and call ourselves Team404, and we have used the following packages

    react-router-dom
    react-bootstrap
    bootstrap
    styled-components
    react-images-upload

## Team404 and their part in CoderStory

1. `Prem -> ` Home Page, Signup Page, Profile Page, Header & Footer for all the pages.
2. `Sharvil -> ` About Page
3. `Manasa -> ` Contact Page
4. `Nishi -> ` Login page

## Thank You
