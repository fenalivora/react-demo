import React from "react";
import { Container } from "react-bootstrap";
import styled from "styled-components";
import codebg from "../assets/codebg.jpg";

const Styles = styled.div`
.box{
    background: url('${codebg}');
    background-size: 20%;
    z-index: -2;
}

    .line {
        width: 33em;
        color: white;
        background: black;
        margin: 0 auto;
        border-right: 2px solid rgba(255, 255, 255, 0.75);
        font-size: 200%;
        text-align: center;
        white-space: nowrap;
        overflow: hidden;
        transform: translateY(-50%);
    }

    .anim-typewriter {
        animation: typewriter 7s steps(50) 1s 1 normal both,
            blinkTextCursor 500ms steps(50) infinite normal;
    }

    @keyframes typewriter {
        from {
            width: 0;
        }
        to {
            width: 33em;
        }
    }

    @keyframes blinkTextCursor {
        from {
            border-right-color: rgba(255, 255, 255, 0.75);
        }
        to {
            border-right-color: transparent;
        }
    }

    .overlay{
        background-color: black;
        opacity: 0.5;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: -1;
    }
`;

const Profile = () => {
    return (
        <Styles>
            <Container className="my-5">
                <h1 className="display-2"> Hi [Name], </h1>
                <p className="display-4">
                    {" "}
                    Projects <br />0
                </p>
                <div className="box p-4">
                    <div className="overlay"></div>
                    <p className="line anim-typewriter my-5">
                        A portfolio for a Coder by a Coder ; printf("%s Rule
                        World!", "Coders");
                    </p>
                </div>
            </Container>
        </Styles>
    );
};

export default Profile;
