import React, { useState } from "react";
import styled from "styled-components";
import Container from "react-bootstrap/Container";
import Badge from "react-bootstrap/Badge";
import Form from "react-bootstrap/Form";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import ImageUploader from "react-images-upload";
import { Link } from "react-router-dom";

const Styles = styled.div`
    .main-content {
        margin-bottom: 10%;
        margin-top: 5%;
    }
`;

const uploadButtonStyle = {
    background: "#ffc107",
    color: "black",
    fontWeight: "bold",
    borderRadius: "5px",
};

const uploadLabelStyle = {
    fontSize: "20px",
};

function Signup() {
    //const [picture, setPicture] = useState();

    const onUpload = (picture) => {
        //setPicture(picture);
    };

    return (
        <Styles>
            <Container className="main-content">
                <h1 className="display-3">
                    Glad to see you <Badge variant="warning"> create </Badge>{" "}
                    your story.
                </h1>
                <hr />
                <Form className="my-5">
                    <Form.Row>
                        <Form.Group as={Col} controlId="formGridFirstName">
                            <Form.Label>First Name</Form.Label>
                            <Form.Control placeholder="Enter First Name" />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridLastName">
                            <Form.Label>Last Name</Form.Label>
                            <Form.Control placeholder="Enter Last Name" />
                        </Form.Group>
                    </Form.Row>
                    <Form.Row>
                        <Form.Group as={Col} controlId="formGridEmail">
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                                type="email"
                                placeholder="Enter email"
                            />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridNumber">
                            <Form.Label>Phone</Form.Label>
                            <Form.Control
                                type="tel"
                                placeholder="Enter Phone"
                            />
                        </Form.Group>
                    </Form.Row>

                    <Form.Row>
                        <Form.Group as={Col} controlId="formGridPassword">
                            <Form.Label>Password</Form.Label>
                            <Form.Control
                                type="password"
                                placeholder="Enter Password"
                            />
                        </Form.Group>

                        <Form.Group
                            as={Col}
                            controlId="formGridConfirmPassword"
                        >
                            <Form.Label>Confirm Password</Form.Label>
                            <Form.Control
                                type="password"
                                placeholder="Re-enter Password"
                            />
                        </Form.Group>
                    </Form.Row>

                    <Form.Group controlId="formGridAddress1">
                        <Form.Label>Address</Form.Label>
                        <Form.Control placeholder="1234 Main St" />
                    </Form.Group>

                    <Form.Group controlId="formGridAddress2">
                        <Form.Label>Address 2</Form.Label>
                        <Form.Control placeholder="Apartment, studio, or floor" />
                    </Form.Group>

                    <Form.Row>
                        <Form.Group as={Col} controlId="formGridCity">
                            <Form.Label>City</Form.Label>
                            <Form.Control />
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridState">
                            <Form.Label>Province</Form.Label>
                            <Form.Control as="select" defaultValue="Choose...">
                                <option disabled>Choose Province</option>
                                <option>Ontario</option>
                                <option>Quebec</option>
                            </Form.Control>
                        </Form.Group>

                        <Form.Group as={Col} controlId="formGridZip">
                            <Form.Label>Postal Code</Form.Label>
                            <Form.Control />
                        </Form.Group>
                    </Form.Row>

                    <ImageUploader
                        className="my-5"
                        singleImage="true"
                        withPreview="true"
                        label="Picture will be sent for review. There should be a face [and only one 😉]"
                        buttonStyles={uploadButtonStyle}
                        buttonText="Upload Profile Picture"
                        onChange={onUpload}
                        labelStyles={uploadLabelStyle}
                        imgExtension={[".jpg", ".png"]}
                        maxFileSize={15000000}
                    />

                    <Link to="/profile">
                        <Button
                            variant="primary"
                            type="submit"
                            className="font-weight-bold my-5"
                            block
                        >
                            Create my story
                        </Button>
                    </Link>
                </Form>
            </Container>
        </Styles>
    );
}

export default Signup;
