import React from "react";
import styled from "styled-components";
import Container from "react-bootstrap/Container";
import Badge from "react-bootstrap/Badge";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";

const Styles = styled.div`
    .form-login {
        width: 50%;
        margin: auto;
    }

    .main-content {
        margin-bottom: 10%;
        margin-top: 5%;
    }

    .no-decor-link {
        text-decoration: none;

        &:focus,
        &:hover,
        &:visited,
        &:link,
        &:active {
            text-decoration: none;
        }
    }
`;

const Login = () => (
    <Styles>
        <Container className="main-content">
            <h1 className="display-3 my-5 text-center">
                {" "}
                Welcome Back <Badge variant="warning">Coder</Badge>
            </h1>
            <hr />
            <div className="form-login my-5">
                <Form>
                    <Form.Group controlId="formBasicEmail">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="Enter email" />
                        <Form.Text className="text-muted">
                            Because that's how we load your unique story.
                        </Form.Text>
                    </Form.Group>

                    <Form.Group controlId="formBasicPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" placeholder="Password" />
                    </Form.Group>
                    <Button
                        variant="primary"
                        type="submit"
                        block
                        className="my-5 font-weight-bold"
                    >
                        Login
                    </Button>
                    <Form.Text className="text-muted text-center">
                        Not having a story with us?
                    </Form.Text>
                </Form>
                <hr />
                <Form>
                    <Link to="/signup" className="no-decor-link">
                        <Button
                            variant="warning"
                            className="my-5 font-weight-bold"
                            block
                        >
                            Create a Story
                        </Button>
                    </Link>
                </Form>
            </div>
        </Container>
    </Styles>
);

export default Login;
