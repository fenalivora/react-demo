import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Home from "./Components/Home";
import About from "./Components/About";
import Contact from "./Components/Contact";
import NoMatch from "./Components/NoMatch";
import NavigationBar from "./Components/NavigationBar";
import Footer from "./Components/Footer";
import Login from "./Components/Login";
import Signup from "./Components/Signup";
import Profile from "./Components/Profile";

function App() {
    return (
        <React.Fragment>
            <NavigationBar />
            <Router>
                <Switch>
                    <Route exact path="/" component={Home} />
                    <Route path="/about" component={About} />
                    <Route path="/contact" component={Contact} />
                    <Route path="/login" component={Login} />
                    <Route path="/signup" component={Signup} />
                    <Route path="/profile" component={Profile} />
                    <Route component={NoMatch} />
                </Switch>
            </Router>
            <Footer />
        </React.Fragment>
    );
}

export default App;
